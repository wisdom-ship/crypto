import { OrderSide, OrderType, prisma, TradeType } from '@prisma/client';
import { CONFIG } from './config';

export async function calculatePnL(tradeId: string) {
  const trade = await prisma.trade.findUnique({
    where: { id: tradeId },
  });

  if (!trade) throw new Error('Trade not found');

  // Mock current price - in production, this would come from market data
  const currentPrice = 44000;
  
  const pnl = trade.side === OrderSide.BUY
    ? (currentPrice - trade.price) * trade.amount * trade.leverage
    : (trade.price - currentPrice) * trade.amount * trade.leverage;

  return pnl;
}

export async function checkMarginRequirements(userId: string) {
  const trades = await prisma.trade.findMany({
    where: {
      userId,
      type: TradeType.MARGIN,
      status: 'OPEN',
    },
  });

  const totalMarginUsed = trades.reduce((acc, trade) => {
    return acc + (trade.amount * trade.price) / trade.leverage;
  }, 0);

  // In production, you'd check this against the user's margin balance
  return {
    marginUsed: totalMarginUsed,
    marginCallRequired: totalMarginUsed >= CONFIG.TRADING.MARGIN_CALL_THRESHOLD,
    liquidationRequired: totalMarginUsed >= CONFIG.TRADING.LIQUIDATION_THRESHOLD,
  };
}

export function calculateTradingFee(amount: number, price: number, isMaker: boolean) {
  const feeRate = isMaker ? CONFIG.TRADING.FEES.MAKER : CONFIG.TRADING.FEES.TAKER;
  return amount * price * feeRate;
}