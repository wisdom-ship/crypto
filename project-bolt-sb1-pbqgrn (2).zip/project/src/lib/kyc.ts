import { DocumentType, prisma, VerificationStatus } from '@prisma/client';
import { CONFIG } from './config';

export async function initiateKYC(userId: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: { documents: true },
  });

  if (!user) throw new Error('User not found');

  const requiredDocs = CONFIG.KYC.LEVELS.BASIC.REQUIRED_DOCS;
  const missingDocs = requiredDocs.filter(
    (docType) => !user.documents.some((doc) => doc.type === docType)
  );

  return {
    canProceed: missingDocs.length === 0,
    missingDocuments: missingDocs,
  };
}

export async function submitDocument(
  userId: string,
  type: DocumentType,
  fileUrl: string
) {
  return prisma.document.create({
    data: {
      userId,
      type,
      url: fileUrl,
      status: VerificationStatus.PENDING,
    },
  });
}

export async function checkWithdrawLimit(userId: string, amount: number) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
  });

  if (!user) throw new Error('User not found');

  const limit = user.kycStatus === 'APPROVED'
    ? CONFIG.KYC.LEVELS.ADVANCED.DAILY_WITHDRAW
    : CONFIG.KYC.LEVELS.BASIC.DAILY_WITHDRAW;

  // In production, you'd check the user's withdrawal history for the last 24 hours
  return amount <= limit;
}