import React from 'react';

export default function Privacy() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4 max-w-4xl">
        <h1 className="text-3xl font-bold mb-8">Privacy Policy</h1>
        
        <div className="bg-white rounded-lg shadow-sm p-8 space-y-6">
          <section>
            <h2 className="text-xl font-semibold mb-4">1. Data Collection</h2>
            <p className="text-gray-600">
              We collect information necessary to provide our services, including but not limited to
              personal identification, financial information, and trading activity data.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-4">2. Use of Information</h2>
            <p className="text-gray-600">
              Your information is used to provide and improve our services, comply with legal obligations,
              and ensure platform security. We never sell your personal data to third parties.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-4">3. Data Security</h2>
            <p className="text-gray-600">
              We implement industry-standard security measures to protect your data. This includes
              encryption, secure servers, and regular security audits.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-4">4. Cookies</h2>
            <p className="text-gray-600">
              We use cookies to enhance your browsing experience and analyze platform usage.
              You can control cookie settings through your browser preferences.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-4">5. Your Rights</h2>
            <p className="text-gray-600">
              You have the right to access, correct, or delete your personal data. Contact our
              support team to exercise these rights.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-4">6. Contact Us</h2>
            <p className="text-gray-600">
              For any privacy-related concerns or questions, please contact our Data Protection Officer
              at privacy@cryptohivex.com
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}