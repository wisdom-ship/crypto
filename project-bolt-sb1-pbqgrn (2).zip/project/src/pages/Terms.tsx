import React from 'react';

export default function Terms() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="container mx-auto px-4 max-w-4xl">
        <h1 className="text-3xl font-bold mb-8">Terms and Conditions</h1>
        
        <div className="bg-white rounded-lg shadow-sm p-8 space-y-6">
          <section>
            <h2 className="text-xl font-semibold mb-4">1. Introduction</h2>
            <p className="text-gray-600">
              These Terms and Conditions govern your use of CryptoHiveX's services. By accessing or using our platform,
              you agree to be bound by these terms. Please read them carefully.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-4">2. Eligibility</h2>
            <p className="text-gray-600">
              To use our services, you must be at least 18 years old and legally able to enter into contracts.
              By using our platform, you represent and warrant that you meet these requirements.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-4">3. Trading Rules</h2>
            <p className="text-gray-600">
              Users must comply with all applicable trading rules and regulations. Market manipulation,
              fraudulent activities, and other prohibited practices are strictly forbidden.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-4">4. Account Security</h2>
            <p className="text-gray-600">
              You are responsible for maintaining the confidentiality of your account credentials.
              Any activities that occur under your account are your responsibility.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-4">5. Risk Disclosure</h2>
            <p className="text-gray-600">
              Cryptocurrency trading involves substantial risk. You acknowledge and accept that you
              may sustain losses greater than your deposits.
            </p>
          </section>

          <section>
            <h2 className="text-xl font-semibold mb-4">6. Modifications</h2>
            <p className="text-gray-600">
              We reserve the right to modify these terms at any time. Continued use of the platform
              after changes constitutes acceptance of the modified terms.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}